import {readFileSync,writeFileSync} from 'node:fs';
import {parseArgs} from 'node:util';
import {Simulation} from 'eecircuit-engine';
const {values:a}=parseArgs({options:{web:{type:'boolean'},mismatch:{type:'string',default:'5'},cap:{type:'string',default:'10'},width:{type:'string',default:'60'},leak:{type:'string',default:'0'},load:{type:'string',default:'10'}}});
const get=(k,lo,hi)=>{const x=Number(a[k]);if(!Number.isFinite(x)||x<lo||x>hi)throw Error(k+' must be in '+lo+'–'+hi);return x;};
const deck=readFileSync(new URL('cp.cir',import.meta.url),'utf8');
const sim=new Simulation();
await sim.start();
const cases=a.web ? [0,5,10].flatMap(m=>[5,10,20].map(c=>[m,c])) : [[get('mismatch',0,30),get('cap',1,30)]];
const width=get('width',5,200), leak=get('leak',0,10),load=get('load',1,15);
const rows=[];
for(const [m,c] of cases){
 sim.setNetList(deck.replace(/^\.param .*$/m,`.param mismatch=${m/100} cap=${c}p width=${width}n leak=${leak}u load=${load}k`));
 const res=await sim.runSim();
 const data=name=>res?.data?.find(x=>x.name===name)?.values;
 const t=data('time'),v=data('v(ctrl)');
 if(!t || !v || t.at(-1)<4.999e-6 || t.length!==v.length)throw Error('Incomplete transient');
 let j=0;
 const trace=Array.from({length:500},(_,i)=>{
  const x=4e-6+i*2e-9;
  while(t[j+1]<x)j++;
  return Number((v[j]+(v[j+1]-v[j])*(x-t[j])/(t[j+1]-t[j])).toFixed(8));
 });
 rows.push({m,c,trace});
 if(!a.web)writeFileSync('vctrl.csv','time_s,vctrl_v\n'+trace.map((x,i)=>[(i*2e-9).toExponential(6),x].join(',')).join('\n')+'\n');
}
if(a.web)writeFileSync('cp-data.js','globalThis.pllCP='+JSON.stringify(rows)+';\n');
