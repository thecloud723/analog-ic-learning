# 第 7、13 章 · 充电泵控制端纹波
在 Node.js 22+ 中运行。EEcircuit-engine 1.9.0（ngspice WASM）固定在锁文件。
首次安装需要 npm 源，随后可离线运行。

```sh
npm ci
node run.mjs --mismatch 5 --cap 10 --width 60 --leak 0 --load 10
node run.mjs --web
```

第一条仿真生成 vctrl.csv，可导入第 13 章。第二条仿真生成网页预跑的九组数据。
参数分别为下拉电流偏小百分比、电容 pF、重叠脉宽 ns、下拉漏电 µA、偏置等效负载 kΩ。两路每 1 µs 同时开启，边沿 1 ns。
电阻将控制端拉向 0.9 V，用于固定这个局部周期试验的 DC 工作点。网表采用理想脉冲电流源，练习失配与滤波的关系。
CSV 是 4–5 µs 最后一周期，重采样间隔 2 ns。网页去掉平均电压后用于 VCO 小调制边带估计。
