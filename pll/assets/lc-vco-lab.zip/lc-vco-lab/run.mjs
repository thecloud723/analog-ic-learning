import {readFileSync, mkdirSync, writeFileSync} from 'node:fs';
import {resolve, join} from 'node:path';
import {parseArgs} from 'node:util';
import {Simulation} from 'eecircuit-engine';

const defaults = {l:'1',c:'810',rs:'2.2',w:'2.4',length:'0.16',bias:'0.9',kick:'50'};
const ranges = {l:[.2,5],c:[100,3000],rs:[.05,100],w:[.4,10],length:[.15,1],bias:[.4,1.3],kick:[1,1000]};
const axes = {l:[.8,1,1.2],c:[680,810,970],rs:[2.2,3.3,18]};
const options = Object.fromEntries(Object.keys(defaults).map(name => [name,{type:'string',default:defaults[name]}]));
Object.assign(options,{web:{type:'boolean'},out:{type:'string',default:'out'},help:{type:'boolean'}});
const {values:args} = parseArgs({options});
if (args.help) {
  console.log('node run.mjs [--l 1] [--c 810] [--rs 2.2] [--w 2.4] [--length .16] [--bias .9] [--kick 50] [--out out]\nComma-separated values produce a Cartesian sweep. --web reproduces the course presets.');
  process.exit(0);
}
const fields=Object.keys(defaults);
const series=fields.map(name => {
  const [min,max]=ranges[name];
  const values=args.web && axes[name] ? axes[name] : (args.web ? defaults[name] : args[name]).split(',').map(piece => Number(piece.trim()));
  if (values.some(value => !Number.isFinite(value) || value<min || value>max)) throw Error(name+' must be in '+min+'–'+max);
  return [...new Set(values)];
});
const cases=series.reduce((rows,values,i)=>rows.flatMap(row=>values.map(value=>({...row,[fields[i]]:value}))),[{}]);
const output=resolve(args.out);
mkdirSync(output,{recursive:true});
const read = name => readFileSync(new URL(name,import.meta.url),'utf8');
const deck=read('vco.cir').replace(/^\s*\.include ["']?([^\s"']+)["']?\s*$/gm, (_,path)=>
  read(path).replace(/^\s*\.include ["']?([^\s"']+)["']?\s*$/gm, (_,nested)=>read('models/'+nested)));
const sim=new Simulation();
await sim.start();
const points=[];

function window(time, start, end) {
  const indices=[];
  for(let i=0;i<time.length;i++) if(time[i]>=start && time[i]<=end) indices.push(i);
  return indices;
}
function peak(indices,signal) {
  let min=Infinity, max=-Infinity;
  for(const i of indices) { min=Math.min(min,signal[i]); max=Math.max(max,signal[i]); }
  return max-min;
}
function waveSvg(env) {
  const X=i=>48+i*2, Y=v=>172-v*138/Math.max(.8,...env);
  const polyline=env.map((v,i)=>X(i)+','+Y(v).toFixed(2)).join(' ');
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 550 215"><rect width="550" height="215" fill="white"/><path d="M48 25V172H528" fill="none" stroke="#78909c"/><text x="48" y="19">|OUTP − OUTN|, V</text><text x="528" y="200" text-anchor="end">120 ns</text><polyline fill="none" stroke="#176d80" stroke-width="2" points="'+polyline+'"/></svg>\n';
}
for(const [index,params] of cases.entries()) {
  const {l,c,rs,w,length,bias,kick}=params;
  const netlist=deck.replace(/^\.param tankL=.*$/m,
    `.param tankL=${l}n tankC=${c}f lossR=${rs} pairW=${w}u pairL=${length}u tailBias=${bias} startPulse=${kick}u`);
  sim.setNetList(netlist);
  const result=await sim.runSim();
  const vector=name=>result?.data?.find(v=>v.name.toLowerCase()===name)?.values;
  const time=vector('time')?.map(t=>t*1e9), p=vector('v(outp)'), n=vector('v(outn)'), supply=vector('i(vdd)');
  if(!time || time.at(-1)<119.999 || [p,n,supply].some(v=>!v || v.length!==time.length || v.some(x=>!Number.isFinite(x)))) throw Error('Incomplete transient for '+JSON.stringify(params));
  const diff=p.map((v,i)=>v-n[i]);
  const steady=window(time,80,120.001), early=window(time,60,80), late=window(time,100,120.001);
  const edges=[];
  const env=new Array(241).fill(0);
  let energy=0;
  for(let i=0;i<time.length;i++) {
    const bin=Math.min(240,Math.floor(time[i]*2));
    env[bin]=Math.max(env[bin],Math.abs(diff[i]));
    if(i===0 || time[i-1]<80) continue;
    const dt=time[i]-time[i-1];
    if(diff[i-1]<0 && diff[i]>=0) edges.push(time[i-1]-dt*diff[i-1]/(diff[i]-diff[i-1]));
    energy-=1.8*(supply[i]+supply[i-1])*dt/2;
  }
  const vpp=peak(steady,diff);
  const settled=peak(late,diff);
  const state=settled<.01 ? 'decay' : Math.abs(peak(early,diff)-settled)/settled<=.05 && edges.length>2 ? 'steady' : 'transient';
  const f=state==='steady' ? (edges.length-1)/(edges.at(-1)-edges[0]) : null;
  let j=0;
  const sample={p:[],n:[]};
  for(let i=0;i<=200;i++) {
    const t=100+i*.008;
    while(time[j+1]<t) j++;
    const k=(t-time[j])/(time[j+1]-time[j]);
    sample.p.push(Number((p[j]+k*(p[j+1]-p[j])).toFixed(5)));
    sample.n.push(Number((n[j]+k*(n[j+1]-n[j])).toFixed(5)));
  }
  const point={...params,state,f,vpp,power:1000*energy/(time.at(-1)-time[steady[0]]),env:env.map(v=>Number(v.toFixed(5))),...sample};
  points.push(point);
  const key='case-'+String(index+1).padStart(2,'0');
  writeFileSync(join(output,key+'.svg'),waveSvg(point.env));
  if(!args.web) writeFileSync(join(output,key+'.csv'),'time_ns,outp_v,outn_v,supply_a\n'+time.map((t,i)=>[t,p[i],n[i],-supply[i]].join(',')).join('\n')+'\n');
  console.log(key,JSON.stringify(params),state,f?.toFixed(3) ?? '–',vpp.toFixed(3));
}
const columns=[...fields,'state','f','vpp','power'];
writeFileSync(join(output,'metrics.csv'),columns.join(',')+'\n'+points.map(p=>columns.map(c=>p[c]??'').join(',')).join('\n')+'\n');
if(args.web) writeFileSync(join(output,'web-data.json'),JSON.stringify(points));
