# PLL 第 8 章 · LC VCO 仿真实验

交叉耦合差分 LC VCO，1.8 V，SKY130 NMOS TT，27 °C。每侧有一个带串联损耗的电感和一个对地电容，左右两侧共同扫参。电容为固定值，代表电压调谐曲线中的一个工作点。1 ns 时注入一次差分启动电流。MOS 交叉耦合对和尾管使用 BSIM4 模型。

## 运行

安装 Node.js 22 或更新版本。网页观看时不需要 Node.js。首次 npm 安装依赖时需要联网。

```sh
npm ci
node run.mjs
```

`out/case-01.svg` 是起振包络，`out/case-01.csv` 是瞬态电压与供电电流，`out/metrics.csv` 是汇总。用浏览器打开 SVG 即可查看。环境依赖锁定为 EEcircuit-engine 1.9.0（ngspice 45.2 WASM），本实验用 Node.js 24.22.1 验证。也可以直接用原生 ngspice 执行 `vco.cir`，原生版的数值容差和版本可能不同。

## 复现课程数据

```sh
node run.mjs --web --out web
```

输出 27 组包络 SVG、指标 CSV 和网页读取的 `web-data.json`。随包附 `baseline.csv`，对应网页使用的基准数据。固定 L=1 nH、C=810 fF，先比较 2.2 Ω 和 18 Ω 的结果。理想 LC 频率估算在这两个条件下相同，SPICE 包络表明它们能否维持振荡。

## 扫参

```sh
node run.mjs --l 1 --c 810 --rs 2.2,2.6,3.0,3.3 --out loss-sweep
node run.mjs --rs 3.3 --w 2.4,3.0 --length .16,.18 --bias .9,.95 --out mos-sweep
```

| 参数 | 单位 | 改动的电路部位 |
| --- | --- | --- |
| `--l` | nH | 左右两侧电感 |
| `--c` | fF | 左右两侧电容 |
| `--rs` | Ω | 每个电感支路的串联损耗 |
| `--w`、`--length` | µm | X1/X2 每个并联单元的 W 和 L |
| `--bias` | V | 尾管栅极偏置 |
| `--kick` | µA | 一次性启动脉冲电流幅值 |

逗号分隔的值会组合成一次扫参。用 `node run.mjs --help` 查看默认值。网表中 X1/X2 和 X3 各由九个相同器件并联。默认参数画在 `schematic.svg` 中。

## 结果口径

运行 120 ns，最大时间步长 2 ps。每 0.5 ns 取一次差分振幅峰值用于起振包络。80–120 ns 内的差分上升过零点用于稳态频率，峰峰值取同一窗口，功耗为该窗口的平均 1.8 V 供电功率。后段峰峰值低于 10 mV 标为 `decay`，60–80 ns 与 100–120 ns 的峰峰值相差超过 5% 标为 `transient`。这些分类受记录长度限制，尤其是起振边界附近。

SKY130 模型源版本为 `f62031a1be9aefe902d6d54cddd6f59b57627436`，许可证在 `models/LICENSE`。这是无外加连续扰动的起振与调频实验。
